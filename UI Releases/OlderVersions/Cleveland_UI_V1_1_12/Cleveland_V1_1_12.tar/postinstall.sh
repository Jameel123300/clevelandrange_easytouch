#!/bin/sh

echo "DO_NOT_REBOOT"

cd /opt/Cleveland/update_1/
echo "Running update script"
./updatescript.sh
echo "finished update script"
