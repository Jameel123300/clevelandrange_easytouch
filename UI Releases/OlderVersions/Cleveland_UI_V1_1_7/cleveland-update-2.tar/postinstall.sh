#!/bin/sh

echo "DO_NOT_REBOOT"

cd /opt/Cleveland/update-2/
./updatescript.sh
